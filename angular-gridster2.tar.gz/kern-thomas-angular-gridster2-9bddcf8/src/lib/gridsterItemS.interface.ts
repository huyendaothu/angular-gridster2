export interface GridsterItemS {
  x: number;
  y: number;
  rows: number;
  cols: number;

  [propName: string]: any;
}
